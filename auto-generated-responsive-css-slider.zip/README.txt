A Pen created at CodePen.io. You can find this one at http://codepen.io/dudleystorey/pen/xDrCw.

 Takes the code of my [responsive CSS slider](http://thenewcode.com/627/Make-A-Responsive-CSS3-Image-Slider) and auto-generates the required styles with progressive JavaScript, based on the number of images and two user-defined timing variables. [More information on my blog](http://thenewcode.com/838/CSSslidy-An-Auto-Generated-Responsive-CSS3-Image-Slider).
UPDATE: added a [GitHub Page](http://dudleystorey.github.io/CSSslidy/) & [repo](https://github.com/dudleystorey/CSSslidy)